"""
IFT Quantum-Manifold Co-Evolution Prototype
===========================================

This is a classical/hybrid research prototype for:
1. Coupled Lorenz-type nonlinear dynamics on a triangulated manifold.
2. Topological invariant checks.
3. State-driven edge-flip surgery that preserves manifold topology.
4. Rebuilding the interaction graph after each accepted surgery.

The quantum portion is represented by the local Lorenz update primitive.
A separate Classiq synthesis example is provided in:
    classiq_lorenz_step_prototype.py

Recommended first run:
    python ift_quantum_manifold_prototype.py

Dependencies:
    numpy, scipy, matplotlib
"""

from __future__ import annotations

from dataclasses import dataclass
from collections import defaultdict, deque
from typing import Dict, Iterable, List, Sequence, Set, Tuple
import math
import random

import matplotlib.pyplot as plt
import numpy as np


Edge = Tuple[int, int]
Face = Tuple[int, int, int]


def canonical_edge(a: int, b: int) -> Edge:
    return (a, b) if a < b else (b, a)


def oriented_area(points: np.ndarray, face: Face) -> float:
    a, b, c = points[list(face)]
    return 0.5 * float(np.cross(b - a, c - a))


def orient_ccw(points: np.ndarray, face: Sequence[int]) -> Face:
    f = tuple(int(v) for v in face)
    if oriented_area(points, f) < 0:
        return (f[0], f[2], f[1])
    return f


def build_rectangular_triangulation(
    nx: int = 8, ny: int = 8, jitter: float = 0.035, seed: int = 7
) -> Tuple[np.ndarray, List[Face]]:
    """Create an oriented triangulated disk on a rectangular grid."""
    rng = np.random.default_rng(seed)
    xs, ys = np.meshgrid(np.linspace(0, 1, nx), np.linspace(0, 1, ny))
    points = np.column_stack([xs.ravel(), ys.ravel()])

    # Jitter only interior vertices.
    for j in range(1, ny - 1):
        for i in range(1, nx - 1):
            idx = j * nx + i
            points[idx] += rng.normal(0.0, jitter, size=2)

    faces: List[Face] = []
    for j in range(ny - 1):
        for i in range(nx - 1):
            v00 = j * nx + i
            v10 = j * nx + (i + 1)
            v01 = (j + 1) * nx + i
            v11 = (j + 1) * nx + (i + 1)

            # Alternate diagonals to avoid a uniform directional bias.
            if (i + j) % 2 == 0:
                cells = [(v00, v10, v11), (v00, v11, v01)]
            else:
                cells = [(v00, v10, v01), (v10, v11, v01)]
            faces.extend(orient_ccw(points, f) for f in cells)
    return points, faces


def edge_to_faces(faces: Sequence[Face]) -> Dict[Edge, List[int]]:
    mapping: Dict[Edge, List[int]] = defaultdict(list)
    for fi, (a, b, c) in enumerate(faces):
        for e in (canonical_edge(a, b), canonical_edge(b, c), canonical_edge(c, a)):
            mapping[e].append(fi)
    return mapping


def edges_from_faces(faces: Sequence[Face]) -> Set[Edge]:
    return set(edge_to_faces(faces))


def adjacency_from_faces(n_vertices: int, faces: Sequence[Face]) -> List[Set[int]]:
    adjacency = [set() for _ in range(n_vertices)]
    for a, b, c in faces:
        for u, v in ((a, b), (b, c), (c, a)):
            adjacency[u].add(v)
            adjacency[v].add(u)
    return adjacency


def connected_components(adjacency: Sequence[Set[int]]) -> int:
    unseen = set(range(len(adjacency)))
    count = 0
    while unseen:
        count += 1
        root = unseen.pop()
        q = [root]
        while q:
            u = q.pop()
            for v in adjacency[u]:
                if v in unseen:
                    unseen.remove(v)
                    q.append(v)
    return count


def boundary_loops(faces: Sequence[Face]) -> int:
    e2f = edge_to_faces(faces)
    boundary_edges = [e for e, owners in e2f.items() if len(owners) == 1]
    if not boundary_edges:
        return 0

    badj: Dict[int, Set[int]] = defaultdict(set)
    for a, b in boundary_edges:
        badj[a].add(b)
        badj[b].add(a)

    # Count connected boundary components. For a valid 2-manifold boundary,
    # each component is a loop and every boundary vertex has degree 2.
    unseen = set(badj)
    components = 0
    while unseen:
        components += 1
        root = unseen.pop()
        q = [root]
        while q:
            u = q.pop()
            for v in badj[u]:
                if v in unseen:
                    unseen.remove(v)
                    q.append(v)
    return components


def orientability_check(faces: Sequence[Face]) -> bool:
    """
    Check whether face orientations can be assigned consistently.
    Adjacent faces must induce opposite directions on their shared edge.
    """
    directed_edges: List[Dict[Edge, int]] = []
    e2f = edge_to_faces(faces)

    for face in faces:
        a, b, c = face
        local: Dict[Edge, int] = {}
        for u, v in ((a, b), (b, c), (c, a)):
            e = canonical_edge(u, v)
            local[e] = 1 if (u, v) == e else -1
        directed_edges.append(local)

    relation_graph: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
    for edge, owners in e2f.items():
        if len(owners) != 2:
            continue
        f1, f2 = owners
        d1 = directed_edges[f1][edge]
        d2 = directed_edges[f2][edge]
        # Let s_f in {+1,-1} denote whether face f is flipped.
        # Need s1*d1 = -(s2*d2), hence s2 = relation*s1.
        relation = -d1 * d2
        relation_graph[f1].append((f2, relation))
        relation_graph[f2].append((f1, relation))

    signs: Dict[int, int] = {}
    for root in range(len(faces)):
        if root in signs:
            continue
        signs[root] = 1
        q = deque([root])
        while q:
            f = q.popleft()
            for g, relation in relation_graph[f]:
                expected = signs[f] * relation
                if g in signs and signs[g] != expected:
                    return False
                if g not in signs:
                    signs[g] = expected
                    q.append(g)
    return True


@dataclass(frozen=True)
class Invariants:
    vertices: int
    edges: int
    faces: int
    euler_characteristic: int
    connected_components: int
    boundary_loops: int
    nonmanifold_edges: int
    orientable: bool


def compute_invariants(n_vertices: int, faces: Sequence[Face]) -> Invariants:
    e2f = edge_to_faces(faces)
    edges = len(e2f)
    adjacency = adjacency_from_faces(n_vertices, faces)
    return Invariants(
        vertices=n_vertices,
        edges=edges,
        faces=len(faces),
        euler_characteristic=n_vertices - edges + len(faces),
        connected_components=connected_components(adjacency),
        boundary_loops=boundary_loops(faces),
        nonmanifold_edges=sum(len(owners) > 2 for owners in e2f.values()),
        orientable=orientability_check(faces),
    )


def lorenz_network_rhs(
    state: np.ndarray,
    adjacency: Sequence[Set[int]],
    sigma: float,
    rho: float,
    beta: float,
    coupling: float,
) -> np.ndarray:
    """
    Coupled Lorenz dynamics:
      local Lorenz flow + graph-diffusion coupling on x,y,z.
    """
    x, y, z = state.T
    local = np.column_stack(
        [
            sigma * (y - x),
            x * (rho - z) - y,
            x * y - beta * z,
        ]
    )

    diffusive = np.zeros_like(state)
    for i, nbrs in enumerate(adjacency):
        if not nbrs:
            continue
        nbr_idx = np.fromiter(nbrs, dtype=int)
        diffusive[i] = state[nbr_idx].mean(axis=0) - state[i]

    return local + coupling * diffusive


def rk4_step(
    state: np.ndarray,
    adjacency: Sequence[Set[int]],
    dt: float,
    sigma: float,
    rho: float,
    beta: float,
    coupling: float,
) -> np.ndarray:
    rhs = lambda s: lorenz_network_rhs(s, adjacency, sigma, rho, beta, coupling)
    k1 = rhs(state)
    k2 = rhs(state + 0.5 * dt * k1)
    k3 = rhs(state + 0.5 * dt * k2)
    k4 = rhs(state + dt * k3)
    return state + (dt / 6.0) * (k1 + 2*k2 + 2*k3 + k4)


def triangle_quality(points: np.ndarray, face: Face) -> float:
    """1 for equilateral, approaches 0 for degenerate triangles."""
    p = points[list(face)]
    lengths2 = [
        float(np.sum((p[0] - p[1]) ** 2)),
        float(np.sum((p[1] - p[2]) ** 2)),
        float(np.sum((p[2] - p[0]) ** 2)),
    ]
    area = abs(oriented_area(points, face))
    denom = sum(lengths2)
    return 0.0 if denom <= 1e-15 else 4.0 * math.sqrt(3.0) * area / denom


def objective(
    points: np.ndarray,
    faces: Sequence[Face],
    state: np.ndarray,
    geometry_weight: float = 0.30,
    field_weight: float = 1.00,
) -> float:
    """
    Lower is better:
    - field mismatch across edges
    - triangle distortion penalty
    """
    edges = edges_from_faces(faces)
    field_energy = 0.0
    for a, b in edges:
        field_energy += float(np.sum((state[a] - state[b]) ** 2))
    field_energy /= max(1, len(edges))

    qualities = [triangle_quality(points, f) for f in faces]
    geometry_penalty = float(np.mean([(1.0 - q) ** 2 for q in qualities]))
    return field_weight * field_energy + geometry_weight * geometry_penalty


def opposite_vertex(face: Face, edge: Edge) -> int:
    for v in face:
        if v not in edge:
            return v
    raise ValueError("No opposite vertex found")


def propose_edge_flip(
    points: np.ndarray, faces: Sequence[Face], edge: Edge
) -> List[Face] | None:
    e2f = edge_to_faces(faces)
    owners = e2f.get(edge, [])
    if len(owners) != 2:
        return None

    f1_idx, f2_idx = owners
    f1, f2 = faces[f1_idx], faces[f2_idx]
    u, v = edge
    a = opposite_vertex(f1, edge)
    b = opposite_vertex(f2, edge)

    if a == b or canonical_edge(a, b) in e2f:
        return None

    # New triangles must have nonzero area.
    nf1 = orient_ccw(points, (a, b, u))
    nf2 = orient_ccw(points, (b, a, v))
    if abs(oriented_area(points, nf1)) < 1e-10:
        return None
    if abs(oriented_area(points, nf2)) < 1e-10:
        return None

    candidate = list(faces)
    candidate[f1_idx] = nf1
    candidate[f2_idx] = nf2
    return candidate


def attempt_state_driven_surgery(
    points: np.ndarray,
    faces: List[Face],
    state: np.ndarray,
    baseline_invariants: Invariants,
    attempts: int,
    rng: random.Random,
) -> Tuple[List[Face], bool, float, float]:
    current_obj = objective(points, faces, state)
    interior = [
        e for e, owners in edge_to_faces(faces).items() if len(owners) == 2
    ]
    rng.shuffle(interior)

    for edge in interior[:attempts]:
        candidate = propose_edge_flip(points, faces, edge)
        if candidate is None:
            continue

        inv = compute_invariants(len(points), candidate)
        topology_preserved = (
            inv.euler_characteristic == baseline_invariants.euler_characteristic
            and inv.connected_components == baseline_invariants.connected_components
            and inv.boundary_loops == baseline_invariants.boundary_loops
            and inv.nonmanifold_edges == 0
            and inv.orientable == baseline_invariants.orientable
        )
        if not topology_preserved:
            continue

        candidate_obj = objective(points, candidate, state)
        if candidate_obj + 1e-12 < current_obj:
            return candidate, True, current_obj, candidate_obj

    return faces, False, current_obj, current_obj


@dataclass
class Config:
    nx: int = 8
    ny: int = 8
    steps: int = 1200
    dt: float = 0.005
    sigma: float = 10.0
    rho: float = 28.0
    beta: float = 8.0 / 3.0
    coupling: float = 0.12
    surgery_interval: int = 20
    surgery_attempts: int = 80
    seed: int = 11


def run_experiment(config: Config = Config()):
    np_rng = np.random.default_rng(config.seed)
    py_rng = random.Random(config.seed)

    points, faces = build_rectangular_triangulation(
        config.nx, config.ny, seed=config.seed
    )
    initial_faces = list(faces)
    baseline = compute_invariants(len(points), faces)

    state = np_rng.normal(0.0, 0.08, size=(len(points), 3))
    state[:, 0] += 0.1

    history_t = []
    history_obj = []
    history_sync = []
    accepted_steps = []

    for step in range(config.steps + 1):
        adjacency = adjacency_from_faces(len(points), faces)

        if step % 5 == 0:
            history_t.append(step * config.dt)
            history_obj.append(objective(points, faces, state))
            center = state.mean(axis=0)
            history_sync.append(float(np.mean(np.linalg.norm(state - center, axis=1))))

        if step > 0 and step % config.surgery_interval == 0:
            faces, accepted, old_obj, new_obj = attempt_state_driven_surgery(
                points,
                faces,
                state,
                baseline,
                config.surgery_attempts,
                py_rng,
            )
            if accepted:
                accepted_steps.append((step, old_obj, new_obj))

        if step < config.steps:
            state = rk4_step(
                state,
                adjacency,
                config.dt,
                config.sigma,
                config.rho,
                config.beta,
                config.coupling,
            )

    final_inv = compute_invariants(len(points), faces)
    return {
        "points": points,
        "initial_faces": initial_faces,
        "faces": faces,
        "state": state,
        "baseline": baseline,
        "final_invariants": final_inv,
        "history_t": np.asarray(history_t),
        "history_obj": np.asarray(history_obj),
        "history_sync": np.asarray(history_sync),
        "accepted_steps": accepted_steps,
        "config": config,
    }


def plot_mesh(points: np.ndarray, faces: Sequence[Face], values: np.ndarray, title: str):
    fig, ax = plt.subplots(figsize=(7, 6))
    tri = np.asarray(faces)
    mesh = ax.tripcolor(
        points[:, 0],
        points[:, 1],
        tri,
        values,
        shading="gouraud",
    )
    ax.triplot(points[:, 0], points[:, 1], tri, linewidth=0.45)
    fig.colorbar(mesh, ax=ax, label="Local x-state")
    ax.set_aspect("equal")
    ax.set_title(title)
    ax.set_xlabel("manifold coordinate 1")
    ax.set_ylabel("manifold coordinate 2")
    fig.tight_layout()
    return fig


def main():
    result = run_experiment()
    print("Initial invariants:")
    print(result["baseline"])
    print("\nFinal invariants:")
    print(result["final_invariants"])
    print(f"\nAccepted edge flips: {len(result['accepted_steps'])}")
    if result["accepted_steps"]:
        print("First five accepted surgeries (step, objective before, objective after):")
        for row in result["accepted_steps"][:5]:
            print(row)

    plot_mesh(
        result["points"],
        result["initial_faces"],
        result["state"][:, 0],
        "Initial interaction manifold (final x-state shown)",
    )
    plt.savefig("initial_manifold.png", dpi=180)
    plt.show()

    plot_mesh(
        result["points"],
        result["faces"],
        result["state"][:, 0],
        "Evolved interaction manifold (final x-state shown)",
    )
    plt.savefig("evolved_manifold.png", dpi=180)
    plt.show()

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(result["history_t"], result["history_obj"])
    ax.set_xlabel("time")
    ax.set_ylabel("field + geometry objective")
    ax.set_title("Co-evolution objective")
    fig.tight_layout()
    plt.savefig("objective_history.png", dpi=180)
    plt.show()

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(result["history_t"], result["history_sync"])
    ax.set_xlabel("time")
    ax.set_ylabel("mean distance from network state centroid")
    ax.set_title("Network synchronization / dispersion")
    fig.tight_layout()
    plt.savefig("synchronization_history.png", dpi=180)
    plt.show()


if __name__ == "__main__":
    main()
