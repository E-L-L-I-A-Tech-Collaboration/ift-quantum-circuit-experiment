"""
Classiq proof-of-concept: one reversible fixed-point Lorenz Euler step.

Run this separately in Classiq Studio or in a local/Colab environment with:
    pip install -U classiq

You must authenticate a Classiq account before synthesis.

Important:
- Start with small numeric widths. Full 24-bit x/y/z plus arithmetic
  temporaries can synthesize into a very large circuit.
- This file validates the local quantum arithmetic primitive only.
- The manifold topology loop remains classical in the first hybrid prototype.
"""

from classiq import *

# Small synthesis-first format. Increase only after inspecting circuit width/depth.
FP_SIZE = 8
FP_FRAC = 4


@qfunc
def lorenz_euler_step(
    x: QNum[FP_SIZE, SIGNED, FP_FRAC],
    y: QNum[FP_SIZE, SIGNED, FP_FRAC],
    z: QNum[FP_SIZE, SIGNED, FP_FRAC],
    sigma: CReal,
    beta: CReal,
    rho: CReal,
    dt: CReal,
) -> None:
    # In-place fixed-point arithmetic. The synthesis engine creates and
    # uncomputes required workspace according to its arithmetic implementation.
    x += dt * sigma * (y - x)
    y += dt * (x * (rho - z) - y)
    z += dt * (x * y - beta * z)


@qfunc
def main(
    x_out: Output[QNum[FP_SIZE, SIGNED, FP_FRAC]],
    y_out: Output[QNum[FP_SIZE, SIGNED, FP_FRAC]],
    z_out: Output[QNum[FP_SIZE, SIGNED, FP_FRAC]],
) -> None:
    allocate(x_out)
    allocate(y_out)
    allocate(z_out)

    x_out |= 0.125
    y_out |= 0.0
    z_out |= 0.0

    lorenz_euler_step(
        x_out,
        y_out,
        z_out,
        sigma=10.0,
        beta=8.0 / 3.0,
        rho=28.0,
        dt=0.01,
    )


qprog = synthesize(main)
show(qprog)
